import React, { useState, useEffect, useRef } from 'react';
import { format, startOfWeek, endOfWeek, addWeeks, subWeeks, isSameDay, parseISO } from 'date-fns';
import { ChevronLeft, ChevronRight, Plus, X, Paperclip, Trash2, Copy, Check, GripVertical } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './services/utils';
import { analyzeDesignImage } from './services/gemini';
import { WeekData, ScrapbookImage, Tag } from './types';

const DECORATIONS = ['tape', 'pin', 'clip'];

export default function App() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [weekData, setWeekData] = useState<WeekData>({ notes: '', notesHeight: 200, images: [] });
  const [loading, setLoading] = useState(false);
  const [isDraggingNotes, setIsDraggingNotes] = useState(false);
  const notesRef = useRef<HTMLTextAreaElement>(null);

  const weekId = format(currentDate, 'yyyy-ww');
  const weekStart = startOfWeek(currentDate, { weekStartsOn: 1 });
  const weekEnd = endOfWeek(currentDate, { weekStartsOn: 1 });

  useEffect(() => { fetchWeekData(); }, [weekId]);

  const fetchWeekData = async () => {
    try {
      const res = await fetch(`/api/week/${weekId}`);
      const data = await res.json();
      setWeekData(data);
    } catch (err) { console.error(err); }
  };

  const handlePrevWeek = () => setCurrentDate(subWeeks(currentDate, 1));
  const handleNextWeek = () => setCurrentDate(addWeeks(currentDate, 1));

  const handleImageUpload = async (date: Date, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLoading(true);
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      const keywords = await analyzeDesignImage(base64);
      const res = await fetch('/api/images', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          weekId, date: format(date, 'yyyy-MM-dd'), url: base64,
          decorationType: DECORATIONS[Math.floor(Math.random() * DECORATIONS.length)],
          rotation: Math.floor(Math.random() * 10) - 5, keywords
        })
      });
      if (res.ok) fetchWeekData();
      setLoading(false);
    };
    reader.readAsDataURL(file);
  };

  const deleteImage = async (id: number) => {
    if (!confirm('Delete this memory?')) return;
    await fetch(`/api/images/${id}`, { method: 'DELETE' });
    fetchWeekData();
  };

  const deleteTag = async (tagId: number) => {
    await fetch(`/api/tags/${tagId}`, { method: 'DELETE' });
    fetchWeekData();
  };

  const updateNotes = async (notes: string, height: number) => {
    await fetch(`/api/week/${weekId}/notes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ notes, notesHeight: height })
    });
  };

  const handleNotesChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setWeekData(prev => ({ ...prev, notes: e.target.value }));
  };

  const handleNotesResize = (e: React.MouseEvent) => {
    setIsDraggingNotes(true);
    const startY = e.clientY;
    const startHeight = weekData.notesHeight;
    const onMouseMove = (moveEvent: MouseEvent) => {
      const newHeight = Math.max(100, startHeight + (moveEvent.clientY - startY));
      setWeekData(prev => ({ ...prev, notesHeight: newHeight }));
    };
    const onMouseUp = () => {
      setIsDraggingNotes(false);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      updateNotes(weekData.notes, weekData.notesHeight);
    };
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
  };

  const days = [0, 1, 2, 3, 4, 5].map(offset => {
    const d = new Date(weekStart);
    d.setDate(d.getDate() + offset);
    return d;
  });

  return (
    <div className="min-h-screen p-4 md:p-8 scrapbook-grid selection:bg-amber-200">
      <header className="max-w-6xl mx-auto mb-8 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <button onClick={handlePrevWeek} className="p-2 hover:bg-amber-100 rounded-full transition-colors"><ChevronLeft className="w-6 h-6" /></button>
          <div className="text-center">
            <h1 className="text-3xl font-bold accent-font text-amber-900">Design Scrapbook</h1>
            <p className="text-amber-700 handwriting text-lg">Week {format(currentDate, 'w')}, {format(weekStart, 'MMM d')} - {format(weekEnd, 'MMM d, yyyy')}</p>
          </div>
          <button onClick={handleNextWeek} className="p-2 hover:bg-amber-100 rounded-full transition-colors"><ChevronRight className="w-6 h-6" /></button>
        </div>
        {loading && <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-2 text-amber-600 handwriting"><div className="w-4 h-4 border-2 border-amber-600 border-t-transparent rounded-full animate-spin" />AI is analyzing your design...</motion.div>}
      </header>

      <main className="max-w-6xl mx-auto grid grid-cols-1 gap-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {days.slice(0, 3).map(day => <DayCell key={day.toISOString()} day={day} images={weekData.images.filter(img => isSameDay(parseISO(img.date), day))} onUpload={(e) => handleImageUpload(day, e)} onDeleteImage={deleteImage} onDeleteTag={deleteTag} />)}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {days.slice(3, 5).map(day => <DayCell key={day.toISOString()} day={day} images={weekData.images.filter(img => isSameDay(parseISO(img.date), day))} onUpload={(e) => handleImageUpload(day, e)} onDeleteImage={deleteImage} onDeleteTag={deleteTag} />)}
          <DayCell day={new Date(weekStart.getTime() + 5 * 24 * 60 * 60 * 1000)} isWeekend images={weekData.images.filter(img => { const d = parseISO(img.date); return isSameDay(d, new Date(weekStart.getTime() + 5 * 24 * 60 * 60 * 1000)) || isSameDay(d, new Date(weekStart.getTime() + 6 * 24 * 60 * 60 * 1000)); })} onUpload={(e) => handleImageUpload(new Date(weekStart.getTime() + 5 * 24 * 60 * 60 * 1000), e)} onDeleteImage={deleteImage} onDeleteTag={deleteTag} />
        </div>
        <div className="relative group">
          <div className="w-full bg-amber-100/50 border-2 border-amber-200 rounded-xl p-6 shadow-inner transition-all" style={{ height: weekData.notesHeight }}>
            <h3 className="handwriting text-xl text-amber-800 flex items-center gap-2 mb-2"><Paperclip className="w-5 h-5" /> Weekly Notes</h3>
            <textarea ref={notesRef} value={weekData.notes} onChange={handleNotesChange} onBlur={() => updateNotes(weekData.notes, weekData.notesHeight)} placeholder="Jot down your design thoughts here..." className="w-full h-[calc(100%-2rem)] bg-transparent border-none focus:ring-0 handwriting text-xl resize-none placeholder:text-amber-300" />
          </div>
          <div onMouseDown={handleNotesResize} className="absolute bottom-0 left-0 right-0 h-4 cursor-ns-resize flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"><GripVertical className="w-6 h-6 text-amber-400 rotate-90" /></div>
        </div>
      </main>
    </div>
  );
}

function DayCell({ day, isWeekend, images, onUpload, onDeleteImage, onDeleteTag }: any) {
  return (
    <div className={cn("min-h-[300px] bg-white/80 border-2 border-amber-100 rounded-2xl p-4 shadow-sm relative overflow-hidden flex flex-col", isWeekend && "md:col-span-1 bg-amber-50/50")}>
      <div className="flex justify-between items-start mb-4">
        <div><h2 className="accent-font text-2xl text-amber-900">{isWeekend ? 'Weekend' : format(day, 'EEEE')}</h2><p className="handwriting text-amber-600">{format(day, 'MMM d')}</p></div>
        <label className="cursor-pointer p-2 bg-amber-100 hover:bg-amber-200 rounded-full transition-colors"><Plus className="w-5 h-5 text-amber-700" /><input type="file" accept="image/*" className="hidden" onChange={onUpload} /></label>
      </div>
      <div className="flex-1 relative flex flex-wrap gap-4 items-center justify-center">
        <AnimatePresence>{images.map((img: any) => <PolaroidCard key={img.id} image={img} onDelete={() => onDeleteImage(img.id)} onDeleteTag={onDeleteTag} />)}</AnimatePresence>
        {images.length === 0 && <div className="absolute inset-0 flex items-center justify-center opacity-20 pointer-events-none"><p className="handwriting text-lg">No inspirations yet</p></div>}
      </div>
    </div>
  );
}

function PolaroidCard({ image, onDelete, onDeleteTag }: any) {
  const [isHovered, setIsHovered] = useState(false);
  const [copied, setCopied] = useState(false);
  const copyToClipboard = (text: string) => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); };
  const Decoration = () => {
    switch (image.decorationType) {
      case 'tape': return <div className="absolute -top-4 left-1/2 -translate-x-1/2 w-16 h-6 bg-amber-200/60 rotate-2 skew-x-12 z-10 border border-amber-300/30" />;
      case 'pin': return <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-red-500 rounded-full shadow-md z-10"><div className="absolute top-1 left-1 w-1 h-1 bg-white/50 rounded-full" /></div>;
      case 'clip': return <div className="absolute -top-3 left-1/2 -translate-x-1/2 z-10"><Paperclip className="w-8 h-8 text-amber-800 -rotate-45" /></div>;
      default: return null;
    }
  };
  return (
    <motion.div initial={{ scale: 0.8, opacity: 0, rotate: image.rotation * 2 }} animate={{ scale: 1, opacity: 1, rotate: image.rotation }} exit={{ scale: 0.8, opacity: 0 }} whileHover={{ scale: 1.05, zIndex: 20 }} className="relative p-2 pb-8 bg-white polaroid-shadow w-40 flex-shrink-0" onMouseEnter={() => setIsHovered(true)} onMouseLeave={() => setIsHovered(false)}>
      <Decoration />
      <div className="relative aspect-square overflow-hidden bg-amber-50">
        <img src={image.url} alt="Inspiration" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
        <button onClick={onDelete} className="absolute top-1 right-1 p-1 bg-white/80 hover:bg-red-500 hover:text-white rounded-full opacity-0 group-hover:opacity-100 transition-all"><Trash2 className="w-3 h-3" /></button>
      </div>
      <div className="mt-2 flex flex-wrap gap-1">
        {image.tags.length > 0 && (
          <div className="relative group/tags w-full">
            {!isHovered ? (
              <div className="flex items-center gap-1"><span className="bg-amber-100 text-[10px] px-1.5 py-0.5 rounded border border-amber-200 handwriting truncate max-w-[80px]">{image.tags[0].keyword}</span>{image.tags.length > 1 && <span className="text-[10px] text-amber-500 handwriting">+{image.tags.length - 1}</span>}</div>
            ) : (
              <motion.div initial={{ opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }} className="absolute left-0 top-0 z-30 bg-white border border-amber-200 p-2 rounded-lg shadow-xl flex flex-wrap gap-1 min-w-[120px]">
                {image.tags.map((tag: any) => (
                  <div key={tag.id} className="group/tag relative flex items-center">
                    <button onClick={() => copyToClipboard(tag.keyword)} className="bg-amber-50 hover:bg-amber-100 text-[10px] px-1.5 py-0.5 rounded border border-amber-200 handwriting flex items-center gap-1 transition-colors">{tag.keyword}{copied ? <Check className="w-2 h-2 text-green-600" /> : <Copy className="w-2 h-2 opacity-0 group-hover/tag:opacity-100" />}</button>
                    <button onClick={(e) => { e.stopPropagation(); onDeleteTag(tag.id); }} className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full p-0.5 opacity-0 group-hover/tag:opacity-100 transition-opacity"><X className="w-2 h-2" /></button>
                  </div>
                ))}
              </motion.div>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
}
